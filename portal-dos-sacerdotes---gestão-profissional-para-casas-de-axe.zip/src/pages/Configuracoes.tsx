import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db, storage } from '../firebase';
import { doc, getDoc, updateDoc, collection, addDoc, serverTimestamp, query, where, getDocs } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Image, Upload, UserPlus, Shield, Activity, Mail } from 'lucide-react';


const PLAN_LIMITS_USERS = {
  'price_1UEag7BejuJh61udGrM5w6oo': 2, // Essencial
  'price_1UEahkBejuJh61udF758QtDQ': 4, // Comunidade
  'price_1UEaiWBejuJh61uduZGizvCM': 5, // Federação
  'price_1UEajLBejuJh61udOqNGOrVQ': 5, // Anual
};

export default function Configuracoes() {
  const { casa, userRole } = useAuth();
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('MEMBRO');
  const [sendingInvite, setSendingInvite] = useState(false);
  const [inviteSuccess, setInviteSuccess] = useState('');
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('identidade');

  useEffect(() => {
    if (casa?.id) {
      fetchLogo();
      fetchAuditLogs();
    }
  }, [casa?.id]);

  const fetchLogo = async () => {
    if (!casa?.id) return;
    try {
      const docRef = doc(db, 'casas_axe', casa.id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setLogoUrl(docSnap.data().logoUrl || null);
      }
    } catch (error) {
      console.error("Erro ao buscar logo:", error);
    }
  };

  const fetchAuditLogs = async () => {
    if (!casa?.id) return;
    try {
      const q = query(
        collection(db, 'audit_logs'),
        where('id_casa', '==', casa.id)
      );
      const snapshot = await getDocs(q);
      const logs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).sort((a: any, b: any) => b.timestamp?.seconds - a.timestamp?.seconds);
      setAuditLogs(logs);
    } catch (error) {
      console.error("Erro ao buscar logs:", error);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !casa?.id) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('A imagem deve ter no máximo 2MB.');
      return;
    }

    setUploading(true);
    try {
      const fileRef = ref(storage, `logos/${casa.id}_${Date.now()}_${file.name}`);
      await uploadBytes(fileRef, file);
      const url = await getDownloadURL(fileRef);

      const casaRef = doc(db, 'casas_axe', casa.id);
      await updateDoc(casaRef, { logoUrl: url });
      
      setLogoUrl(url);
      alert('Logo atualizada com sucesso!');
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
      alert('Erro ao enviar imagem. Verifique se o Storage está configurado corretamente.');
    } finally {
      setUploading(false);
    }
  };


  const handleRemoveLogo = async () => {
    if (!casa?.id) return;
    setUploading(true);
    try {
      const casaRef = doc(db, 'casas_axe', casa.id);
      await updateDoc(casaRef, { logoUrl: '' });
      setLogoUrl('');
      alert('Logo removida com sucesso!');
    } catch (error) {
      console.error('Erro ao remover logo:', error);
      alert('Erro ao remover imagem.');
    } finally {
      setUploading(false);
    }
  };

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail || !casa?.id) return;

    // Check user limits
    try {
      const limit = PLAN_LIMITS_USERS[casa?.plano as keyof typeof PLAN_LIMITS_USERS] || 2;
      
      const qUsers = query(collection(db, 'users'), where('id_casa', '==', casa.id));
      const snapUsers = await getDocs(qUsers);
      
      const qConvites = query(collection(db, 'convites'), where('id_casa', '==', casa.id), where('status', '==', 'pendente'));
      const snapConvites = await getDocs(qConvites);
      
      const totalUsers = snapUsers.size + snapConvites.size;
      
      if (totalUsers >= limit) {
        alert(`Seu plano atual permite até ${limit} usuários. Por favor, faça o upgrade para adicionar mais diretores.`);
        return;
      }
    } catch (e) {
      console.error(e);
    }

    setSendingInvite(true);
    setInviteSuccess('');
    try {
      // Create an invite code
      const codigo = Math.random().toString(36).substring(2, 10).toUpperCase();
      
      await addDoc(collection(db, 'convites'), {
        email: inviteEmail,
        id_casa: casa.id,
        role: inviteRole,
        codigo,
        status: 'pendente',
        criadoEm: serverTimestamp()
      });

      // Em um cenário real, você integraria com SendGrid/Nodemailer aqui.
      // Como o envio de e-mail requer backend/extensões, exibimos o código.
      setInviteSuccess(`Convite gerado! Código: ${codigo} (O usuário deve inserir isso no cadastro)`);
      setInviteEmail('');
    } catch (error) {
      console.error('Erro ao gerar convite:', error);
      alert('Erro ao gerar convite.');
    } finally {
      setSendingInvite(false);
    }
  };

  if (!casa) return <div>Carregando...</div>;

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-8 animate-in fade-in duration-500">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-3">
          Configurações da Casa
        </h1>
        <p className="text-slate-500 dark:text-slate-400 mt-2">
          Gerencie a identidade visual e os acessos do seu Terreiro.
        </p>
      </header>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-700">
        <button
          onClick={() => setActiveTab('identidade')}
          className={`px-6 py-3 font-medium text-sm transition-colors ${activeTab === 'identidade' ? 'border-b-2 border-[#C59B4B] text-[#C59B4B]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
        >
          Identidade Visual
        </button>
        <button
          onClick={() => setActiveTab('acessos')}
          className={`px-6 py-3 font-medium text-sm transition-colors ${activeTab === 'acessos' ? 'border-b-2 border-[#C59B4B] text-[#C59B4B]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
        >
          Gerenciamento de Acesso
        </button>
        <button
          onClick={() => setActiveTab('auditoria')}
          className={`px-6 py-3 font-medium text-sm transition-colors ${activeTab === 'auditoria' ? 'border-b-2 border-[#C59B4B] text-[#C59B4B]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
        >
          Histórico de Atividades
        </button>
      </div>

      <div className="mt-8">
        {/* TAB: Identidade Visual */}
        {activeTab === 'identidade' && (
          <div className="bg-white dark:bg-[#1E1E1E] border border-slate-200 dark:border-slate-700 rounded-xl p-6 shadow-sm">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-6 flex items-center gap-2">
              <Image className="w-5 h-5 text-[#C59B4B]" />
              Logo do Terreiro (White-label)
            </h2>
            
            <div className="flex items-start gap-8">
              <div className="w-48 h-48 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 flex items-center justify-center bg-slate-50 dark:bg-slate-800 overflow-hidden relative">
                {logoUrl ? (
                  <img src={logoUrl} alt="Logo" className="w-full h-full object-contain p-2" />
                ) : (
                  <div className="text-center text-slate-400">
                    <Image className="w-10 h-10 mx-auto mb-2 opacity-50" />
                    <span className="text-sm">Sem Logo</span>
                  </div>
                )}
              </div>
              
              <div className="flex-1 space-y-4">
                <p className="text-slate-600 dark:text-slate-300 text-sm">
                  Faça o upload da logo do seu Terreiro. Esta imagem será usada nos cabeçalhos dos relatórios PDF e substituirá a logo do ASE CONNECT nas impressões (White-label).
                </p>
                <p className="text-slate-500 text-xs">
                  Formatos aceitos: PNG, JPG. Tamanho máximo: 2MB. Recomendamos imagens com fundo transparente.
                </p>
                
                
                <div className="flex gap-3">
                  <label className="inline-flex items-center gap-2 px-6 py-2.5 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 dark:hover:bg-slate-600 text-white text-sm font-semibold rounded-lg cursor-pointer transition-colors shadow-sm disabled:opacity-50">
                    {uploading ? 'Enviando...' : (
                      <>
                        <Upload className="w-4 h-4" />
                        Alterar Logo
                      </>
                    )}
                    <input 
                      type="file" 
                      accept="image/png, image/jpeg" 
                      className="hidden" 
                      onChange={handleLogoUpload}
                      disabled={uploading}
                    />
                  </label>
                  
                  {logoUrl && (
                    <button
                      onClick={handleRemoveLogo}
                      disabled={uploading}
                      className="inline-flex items-center gap-2 px-6 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 text-sm font-semibold rounded-lg cursor-pointer transition-colors shadow-sm disabled:opacity-50"
                    >
                      Usar logo do sistema
                    </button>
                  )}
                </div>

              </div>
            </div>
          </div>
        )}

        {/* TAB: Acessos */}
        {activeTab === 'acessos' && (
          <div className="bg-white dark:bg-[#1E1E1E] border border-slate-200 dark:border-slate-700 rounded-xl p-6 shadow-sm">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-6 flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-[#C59B4B]" />
              Convidar Usuários
            </h2>

            <form onSubmit={handleSendInvite} className="max-w-md space-y-4">
              <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">
                Gere um código de convite para que membros da diretoria possam criar contas vinculadas ao seu Terreiro.
              </p>

              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">E-mail do Convidado</label>
                <div className="relative">
                  <Mail className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-[#C59B4B] outline-none"
                    placeholder="email@exemplo.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Nível de Acesso (Cargo)</label>
                <div className="relative">
                  <Shield className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <select
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-[#C59B4B] outline-none appearance-none"
                  >
                    <option value="EDITOR">Editor (Pode gerenciar membros/financeiro)</option>
                    <option value="TESTADOR">Testador (Pode ler e adicionar, não deleta)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={sendingInvite}
                className="w-full py-2.5 bg-[#C59B4B] hover:bg-[#B38A3A] text-white font-semibold rounded-lg shadow-sm transition-colors"
              >
                {sendingInvite ? 'Gerando...' : 'Gerar Convite'}
              </button>

              {inviteSuccess && (
                <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-700 dark:text-green-400 rounded-lg text-sm">
                  {inviteSuccess}
                </div>
              )}
            </form>
          </div>
        )}

        {/* TAB: Auditoria */}
        {activeTab === 'auditoria' && (
          <div className="bg-white dark:bg-[#1E1E1E] border border-slate-200 dark:border-slate-700 rounded-xl p-6 shadow-sm">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-6 flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#C59B4B]" />
              Histórico de Atividades
            </h2>

            {auditLogs.length === 0 ? (
              <div className="text-center py-10 text-slate-500">
                Nenhuma atividade registrada ainda. (O registro de logs de auditoria está sendo ativado).
              </div>
            ) : (
              <div className="space-y-4">
                {auditLogs.map(log => (
                  <div key={log.id} className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
                    <p className="text-sm text-slate-800 dark:text-slate-200">
                      <span className="font-semibold">{log.userEmail}</span> {log.action}
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      {log.timestamp ? new Date(log.timestamp.toDate()).toLocaleString() : 'Data desconhecida'}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
