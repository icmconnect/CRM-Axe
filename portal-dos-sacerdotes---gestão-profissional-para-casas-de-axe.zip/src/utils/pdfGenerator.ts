import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
/**
 * Gerador de PDFs dinâmico e centralizado com estilo unificado (Amber)
 */

export interface PDFTableConfig {
  title?: string;
  headers: string[][];
  body: any[][];
}

export interface PDFSummaryField {
  label: string;
  value: string;
}

export interface PDFGeneratorConfig {
  title: string;
  subtitle?: string;
  summaryFields?: PDFSummaryField[];
  tables?: PDFTableConfig[];
  action?: 'download' | 'share';
  fileName: string;
  shareTitle?: string;
  shareText?: string;
  logoUrl?: string | null;
}

/**
 * Carrega uma imagem de URL externa para DataURL base64.
 */
async function loadImgDataUrl(url: string): Promise<string | null> {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error('Erro ao carregar imagem para PDF:', error);
    return null;
  }
}

/**
 * Compartilha o arquivo PDF gerado ou faz fallback para WhatsApp
 */
export async function compartilharPDF(
  blob: Blob,
  fileName: string,
  shareTitle: string,
  shareText: string
): Promise<void> {
  const file = new File([blob], fileName, { type: 'application/pdf' });

  const shareData = {
    title: shareTitle,
    text: shareText,
  };

  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ ...shareData, files: [file] });
        return;
      } else {
        await navigator.share(shareData);
        return;
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Erro ao compartilhar via Web Share:', err);
      } else {
        return; // Cancelado pelo usuário
      }
    }
  }

  // Fallback para download direto
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

/**
 * Gera um PDF unificado e estilizado
 */
export async function gerarPDF(config: PDFGeneratorConfig): Promise<any> {
  const doc = new jsPDF();
  
  // Faixa/Linha decorativa com a cor Amber (#D97706 / RGB 217, 119, 6)
  doc.setFillColor(217, 119, 6);
  doc.rect(0, 0, 210, 8, 'F');
  
  let currentY = 25;

  
  // Renderiza a Logo (Personalizada ou Padrão)
  const logoTargetUrl = config.logoUrl || '/assets/images/logo-nova.png';
  const dataUrl = await loadImgDataUrl(logoTargetUrl);
  
  if (dataUrl) {
    // Calculando tamanho para nao esticar
    // Geralmente logo-nova.png é retangular, mas limitamos a altura e largura
    doc.addImage(dataUrl, 'PNG', 14, 12, 35, 15, undefined, 'FAST');
    currentY = 35;
  } else {
    doc.setFontSize(16);
    doc.setTextColor(217, 119, 6);
    doc.text('ASE CONNECT', 14, 20);
    currentY = 32;
  }


  // Título do documento
  doc.setFontSize(18);
  doc.setTextColor(30, 41, 59); // Slate-800
  doc.text(config.title, 14, currentY);
  
  currentY += 7;

  // Data e hora de geração
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139); // Slate-500
  doc.text(`Gerado em: ${new Date().toLocaleString('pt-BR')}`, 14, currentY);
  
  currentY += 8;
  
  if (config.subtitle) {
    doc.setFontSize(11);
    doc.setTextColor(51, 65, 85); // Slate-700
    doc.text(config.subtitle, 14, currentY);
    currentY += 8;
  }
  
  // Dados de resumo (Labels e valores estruturados)
  if (config.summaryFields && config.summaryFields.length > 0) {
    doc.setFontSize(10);
    doc.setTextColor(51, 65, 85);
    for (const field of config.summaryFields) {
      doc.setFont('helvetica', 'bold');
      doc.text(`${field.label}: `, 14, currentY);
      const labelWidth = doc.getTextWidth(`${field.label}: `);
      doc.setFont('helvetica', 'normal');
      doc.text(field.value, 14 + labelWidth, currentY);
      currentY += 6;
    }
    currentY += 4;
  }
  
  // Adiciona as tabelas dinamicamente
  if (config.tables && config.tables.length > 0) {
    for (const table of config.tables) {
      if (currentY > 260) {
        doc.addPage();
        currentY = 20;
      }
      if (table.title) {
        doc.setFontSize(13);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(30, 41, 59);
        doc.text(table.title, 14, currentY);
        currentY += 6;
      }
      
      autoTable(doc, {
        startY: currentY,
        head: table.headers,
        body: table.body,
        theme: 'grid',
        headStyles: { 
          fillColor: [217, 119, 6], // Amber-600
          textColor: [255, 255, 255],
          fontSize: 9,
          fontStyle: 'bold'
        },
        bodyStyles: {
          fontSize: 8.5,
          textColor: [51, 65, 85]
        },
        alternateRowStyles: {
          fillColor: [248, 250, 252] // Slate-50
        },
        margin: { left: 14, right: 14 }
      });
      
      currentY = (doc as any).lastAutoTable.finalY + 12;
    }
  }

  // Footer em todas as páginas
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text('Gerado por ASE CONNECT - aseconnect.com.br', 105, 290, { align: 'center' });
    doc.text(`Página ${i} de ${pageCount}`, 105, 294, { align: 'center' });
  }
  
  const fileName = config.fileName;
  
  if (config.action === 'download') {
    doc.save(fileName);
  } else {
    const pdfBlob = doc.output('blob');
    await compartilharPDF(
      pdfBlob,
      fileName,
      config.shareTitle || config.title,
      config.shareText || ''
    );
  }

  return doc;
}
